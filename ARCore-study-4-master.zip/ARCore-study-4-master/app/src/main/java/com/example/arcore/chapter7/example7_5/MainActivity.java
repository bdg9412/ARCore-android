package com.example.arcore.chapter7.example7_5;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.hardware.display.DisplayManager;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CheckBox;

import com.google.ar.core.ArCoreApk;
import com.google.ar.core.Camera;
import com.google.ar.core.Config;
import com.google.ar.core.Frame;
import com.google.ar.core.HitResult;
import com.google.ar.core.PointCloud;
import com.google.ar.core.Pose;
import com.google.ar.core.Session;

import java.util.List;

public class MainActivity extends Activity {
    private static final String TAG = MainActivity.class.getSimpleName();
    //레이아웃용 변수 선언
    private CheckBox mCheckBox;
    private GLSurfaceView mSurfaceView;
    //렌더러 변수 선언
    private MainRenderer mRenderer;

    private boolean mUserRequestedInstall = true;
    //ARCore API 호출할 수 있는 진입점이 될 Session 객체 생성위한 변수
    private Session mSession;
    private Config mConfig;

    private float[] mProjMatrix = new float[16];
    private float[] mViewMatrix = new float[16];

    //터치가 발생한 좌표 저장 변수
    private float mLastX;
    private float mLastY;
    private float[] mLastPoint = new float[] { 0.0f, 0.0f, 0.0f };
    private boolean mNewPath = false;
    private boolean mPointAdded = false;

    private static float MIN_DISTANCE = 0.000625f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //레이아웃 관련한 것임으로 전체화면 위한 함수는 레이아웃 부르기 전에 호출
        hideStatusBarAndTitleBar();
        setContentView(R.layout.activity_main);
        //레이아웃 설정값을 액티비티 내에서 사용하기 위해 객체를 할당
        mCheckBox = (CheckBox) findViewById(R.id.check_box);
        mSurfaceView = (GLSurfaceView) findViewById(R.id.gl_surface_view);

        //방향 전환 시 호출되는 콜백 함수
        DisplayManager displayManager = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        if (displayManager != null) {
            displayManager.registerDisplayListener(new DisplayManager.DisplayListener() {
                @Override
                public void onDisplayAdded(int displayId) {
                }
                //onDisplayChanged에 displayId값을 인자로 주어
                //디스플레이가 변경되었음을 렌더러에게 알려준다
                @Override
                public void onDisplayChanged(int displayId) {
                    synchronized (this) {
                        mRenderer.onDisplayChanged();
                    }
                }

                @Override
                public void onDisplayRemoved(int displayId) {
                }
            }, null);
        }

        mRenderer = new MainRenderer(new MainRenderer.RenderCallback() {
            @Override
            public void preRender() {
                //디스플레이 방향이 변경되었을 경우 디스플레이 방향에 맞는 설정
                if (mRenderer.isViewportChanged()) {
                    Display display = getWindowManager().getDefaultDisplay();
                    int displayRotation = display.getRotation();
                    //Session의 디스플레이 방향을 설정
                    //updateSesiion은 setDisplayGeometry()호출
                    //Session클래스의 setDisplayGeometry()를 이용하여 디스플레이 방향 설정 가능
                    //이때 display.getRotation을 이용하여 얻은 rotate 정수값을 인자로 전달
                    mRenderer.updateSession(mSession, displayRotation);
                }
                //렌더러에서 카메라 영상을 그리기 위해 생성한 텍스쳐 객체를 Session 객체와 연결시켜 준다.
                //이때 인자로 getTextureId함수를 이용하여 mCamera가 null이면 -1
                //그렇지 않다면 getTextureId()의 return값인 mTextures[0];을 전달해준다
                mSession.setCameraTextureName(mRenderer.getTextureId());
                //frame 변화시 이를 반환(반환 값은 frame)하여 할당
                Frame frame = mSession.update();
                if (frame.hasDisplayGeometryChanged()) {
                    mRenderer.transformDisplayGeometry(frame);
                }
                //ARCore 상에서의 포인트 클라우드는 3차원 정보를 갖는 특징점들의 모음
                //이때의 특징점은 영상에서 주변과 구분되는 특징을 잡아낼 수 있는 점
                //예시로 컬러가 구분되는 두 사물의 접점
                //특징 점들의 3차원 좌표값을 가진 포인트들의 값을 frame으로부터 받아온다
                PointCloud pointCloud = frame.acquirePointCloud();
                mRenderer.updatePointCloud(pointCloud);
                pointCloud.release();
                //OpenGL처럼 rendering시에 매트릭스 설정을 해줘야 합니다
                Camera camera = frame.getCamera();
                camera.getProjectionMatrix(mProjMatrix, 0, 0.1f, 100.0f);
                camera.getViewMatrix(mViewMatrix, 0);

                mRenderer.setProjectionMatrix(mProjMatrix);
                mRenderer.updateViewMatrix(mViewMatrix);
                //스크린상에 그릴 경우
                //버튼 클릭 후  true 반환시에
                if (mCheckBox.isChecked()) {
                    //좌표값을 반환받아 옵니다
                    float[] screenPoint = getScreenPoint(mLastX, mLastY,
                            mRenderer.getWidth(), mRenderer.getHeight(),
                            mProjMatrix, mViewMatrix);
                    if (mNewPath) {
                        mNewPath = false;
                        mRenderer.addPath(screenPoint[0], screenPoint[1], screenPoint[2]);
                        mLastPoint[0] = screenPoint[0];
                        mLastPoint[1] = screenPoint[1];
                        mLastPoint[2] = screenPoint[2];
                    }
                    else if (mPointAdded) {
                        if (checkDistance(screenPoint[0], screenPoint[1], screenPoint[2],
                                mLastPoint[0], mLastPoint[1], mLastPoint[2])) {
                            mRenderer.addPoint(screenPoint[0], screenPoint[1], screenPoint[2]);
                            mLastPoint[0] = screenPoint[0];
                            mLastPoint[1] = screenPoint[1];
                            mLastPoint[2] = screenPoint[2];
                        }
                    }
                }
                else {
                    if (mNewPath) {
                        //터치 이벤트 발생후
                        //터치된 좌표(X,Y)를 HitTest에 넘겨준다
                        //만약 해당 위치에서 감지된 점이 있다면 결과는 HitTest 객체에 저장되어 List형태의 반환값으로 받아옵니다.
                        //여기서 HitTest는 카메라와 Hit된 점 사이의 거리, 카메라와 Hit된 점 사이의 포즈 정보 등을 저장하고 있는 클래스
                        List<HitResult> results = frame.hitTest(mLastX, mLastY);
                        for (HitResult result : results) {
                            Pose pose = result.getHitPose();
                            mNewPath = false;
                            mRenderer.addPath(pose.tx(), pose.ty(), pose.tz());
                            mLastPoint[0] = pose.tx();
                            mLastPoint[1] = pose.ty();
                            mLastPoint[2] = pose.tz();
                            break;
                        }
                    } else if (mPointAdded) {
                        List<HitResult> results = frame.hitTest(mLastX, mLastY);
                        for (HitResult result : results) {
                            Pose pose = result.getHitPose();
                            //checkDistance에 의해 true를 반환시
                            //포인트 추가
                            if (checkDistance(pose.tx(), pose.ty(), pose.tz(),
                                    mLastPoint[0], mLastPoint[1], mLastPoint[2])) {
                                mRenderer.addPoint(pose.tx(), pose.ty(), pose.tz());
                                mLastPoint[0] = pose.tx();
                                mLastPoint[1] = pose.ty();
                                mLastPoint[2] = pose.tz();
                                break;
                            }
                        }
                        mPointAdded = false;
                    }
                }
            }
        });
        mSurfaceView.setPreserveEGLContextOnPause(true);
        mSurfaceView.setEGLContextClientVersion(2);
        mSurfaceView.setRenderer(mRenderer);
        mSurfaceView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }

    @Override
    protected void onPause() {
        super.onPause();

        mSurfaceView.onPause();
        mSession.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();

        requestCameraPermission();
        //Session 객체 생성 및 ARCore SDK가 설치되어있는지 여부 확인+
        try {
            if (mSession == null) {
                switch (ArCoreApk.getInstance().requestInstall(this, mUserRequestedInstall)) {
                    case INSTALLED:
                        mSession = new Session(this);
                        Log.d(TAG, "ARCore Session created.");
                        break;
                    case INSTALL_REQUESTED:
                        mUserRequestedInstall = false;
                        Log.d(TAG, "ARCore should be installed.");
                        break;
                }
            }
        }
        catch (UnsupportedOperationException e) {
            Log.e(TAG, e.getMessage());
        }
        //arcORE 환경 값들을 설정할 수 있는 Config 객체를 생성
        mConfig = new Config(mSession);
        if (!mSession.isSupported(mConfig)) {
            Log.d(TAG, "This device is not support ARCore.");
        }
        mSession.configure(mConfig);
        mSession.resume();

        mSurfaceView.onResume();
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        mLastX = event.getX();
        mLastY = event.getY();
        switch (event.getAction()) {
            //터치 발생시 ACTIO_DOWN 이벤트가 발생
            //이는 PATH가 시작되었음을 의미
            case MotionEvent.ACTION_DOWN:
                mNewPath = true;
                mPointAdded = true;
                break;
            //터치 유지하며 움직일시 ACTION_MOVE 이벤트가 발생
            //이는 새로운 점들이 계속 추가된다는 의미
            case MotionEvent.ACTION_MOVE:
                mPointAdded = true;
                break;
            //스크린 상에서 손가락을 떼어 ACTION_UP 이벤트가 발생
            //하나의 그림이 끝났음을 의미
            case MotionEvent.ACTION_UP:
                mPointAdded = false;
                break;
        }
        return true;
    }
    //취소 버튼 클릭시 removePath()함수 호출
    public void onUndoButtonClick(View view) {
        mRenderer.removePath();
    }
    //스크린 상의 좌표보다 조금앞에 있는 3차원 좌표값을 구하는 함수
    //인자로 x,y좌표 width&height 그리고 matrix view를 전달합니다
    public float[] getScreenPoint(float x, float y, float w, float h,
                                    float[] projMat, float[] viewMat) {
        float[] position = new float[3];
        float[] direction = new float[3];
        //3차원 좌표값 설정
        x = x * 2 / w - 1.0f;
        y = (h - y) * 2 / h - 1.0f;

        float[] viewProjMat = new float[16];
        Matrix.multiplyMM(viewProjMat, 0, projMat, 0, viewMat, 0);

        float[] invertedMat = new float[16];
        Matrix.setIdentityM(invertedMat, 0);
        Matrix.invertM(invertedMat, 0, viewProjMat, 0);

        float[] farScreenPoint = new float[]{x, y, 1.0F, 1.0F};
        float[] nearScreenPoint = new float[]{x, y, -1.0F, 1.0F};
        float[] nearPlanePoint = new float[4];
        float[] farPlanePoint = new float[4];

        Matrix.multiplyMV(nearPlanePoint, 0, invertedMat, 0, nearScreenPoint, 0);
        Matrix.multiplyMV(farPlanePoint, 0, invertedMat, 0, farScreenPoint, 0);

        position[0] = nearPlanePoint[0] / nearPlanePoint[3];
        position[1] = nearPlanePoint[1] / nearPlanePoint[3];
        position[2] = nearPlanePoint[2] / nearPlanePoint[3];

        direction[0] = farPlanePoint[0] / farPlanePoint[3] - position[0];
        direction[1] = farPlanePoint[1] / farPlanePoint[3] - position[1];
        direction[2] = farPlanePoint[2] / farPlanePoint[3] - position[2];

        normalize(direction);

        position[0] += (direction[0] * 0.1f);
        position[1] += (direction[1] * 0.1f);
        position[2] += (direction[2] * 0.1f);
        //위치값 반환
        return position;
    }

    private void normalize(float[] v) {
        double norm = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        v[0] /= norm;
        v[1] /= norm;
        v[2] /= norm;
    }
    //마지막 포인트와의 거리를 계산하고 일정 범위 밖의 포인트만 추가하도록 하는 함수
    //기존 포인트와 나중 포인트의 x,y,z 좌표를 인자로 받는다
    //이값을 이용하여 두 점 사이의 거리가 최소 이상일떄만 true를 반환
    public boolean checkDistance(float x1, float y1, float z1, float x2, float y2, float z2) {
        float x = x1 - x2;
        float y = y1 - y2;
        float z = z1 - z2;
        return (Math.sqrt(x*x + y*y + z*z) > MIN_DISTANCE);
    }
    //매니페스트에 추가한 카메라 권한을 부여받기 위하여
    //권한 승인이 되지 않았다면 requestpermissions()함수를 이용하여 카메라권한 요청 문구를 띄운다
    private void requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA}, 0);
        }
    }
    //상태 바와 타이틀 바를 제거하고 전체 화면 모드로 동작을 위한 함수
    //윈도우 객체를 이용하여 FULL SCREEN으로 동작하도록 합니다.
    private void hideStatusBarAndTitleBar() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
}
