package com.example.arcore.chapter7.example7_3;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.hardware.display.DisplayManager;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.ar.core.Anchor;
import com.google.ar.core.ArCoreApk;
import com.google.ar.core.Camera;
import com.google.ar.core.Config;
import com.google.ar.core.Frame;
import com.google.ar.core.HitResult;
import com.google.ar.core.PointCloud;
import com.google.ar.core.Pose;
import com.google.ar.core.Session;

import java.util.List;

public class MainActivity extends Activity {
    private static final String TAG = MainActivity.class.getSimpleName();

    private String mTextString;
    private TextView mTextView;
    //GLSurfaceView 객체를 멤버 변수로 선언
    private GLSurfaceView mSurfaceView;
    //OpenGL ES를 사용하기위해
    private MainRenderer mRenderer;

    private boolean mUserRequestedInstall = true;
    //Session 객체를 생성합니다.
    //Session 클래스는 ARCore API사용을 위한 진입점이 됩니다.
    //이로써 카메라 이미지, 디바이스의 포즈에 접근할 수 있는 프레임 을 받아올 수 있습니다.
    private Session mSession;
    //config 객체를 생성합니다.
    //setting을 위하여 사용합니다.
    private Config mConfig;

    //터치 이벤트 처리 위한 변수 선언
    //터치된 스크린의 X,Y 좌표
    //터치 여부
    private float mCurrentX;
    private float mCurrentY;
    private boolean mTouched = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideStatusBarAndTitleBar();
        setContentView(R.layout.activity_main);
        //findViewById함수를 이용하여 레이아웃으로부터 TextView 객체를 받아온다
        mTextView = (TextView) findViewById(R.id.ar_core_text);
        //findViewById함수를 이용하여 레이아웃으로부터 GLSurfaceView 객체를 받아온다
        mSurfaceView = (GLSurfaceView) findViewById(R.id.gl_surface_view);

        //디스플레이 방향이 바뀔때마다 방향변화를 알리기위한 콜백 함수
        DisplayManager displayManager = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        if (displayManager != null) {
            displayManager.registerDisplayListener(new DisplayManager.DisplayListener() {
                @Override
                public void onDisplayAdded(int displayId) {
                }

                @Override
                public void onDisplayChanged(int displayId) {
                    synchronized (this) {
                        mRenderer.onDisplayChanged();
                    }
                }

                @Override
                public void onDisplayRemoved(int displayId) {
                }
            }, null);
        }
        mRenderer = new MainRenderer(new MainRenderer.RenderCallback() {
            //새로운 프레임을 받아왔을 때 처리를 preRender가 맡아서 한다.
            @Override
            public void preRender() {
                if (mRenderer.isViewportChanged()) {
                    Display display = getWindowManager().getDefaultDisplay();
                    int displayRotation = display.getRotation();
                    //Session의 디스플레이 방향을 설정
                    //Session클래스의 setDisplayGeometry()를 이용하여 디스플레이 방향 설정 가능
                    //이때 화면 방향과 화면 크기를 인자로 주어야 한다
                    mRenderer.updateSession(mSession, displayRotation);
                }
                //렌더러에서 생성한 텍스쳐를 Session 객체와 연결 시키는 부분
                mSession.setCameraTextureName(mRenderer.getTextureId());

                //frame 변화시 이를 반환(반환 값은 frame)하여 할당
                Frame frame = mSession.update();
                if (frame.hasDisplayGeometryChanged()) {
                    mRenderer.transformDisplayGeometry(frame);
                }
                //ARCore 상에서의 포인트 클라우드는 3차원 정보를 갖는 특징점들의 모음
                //이때의 특징점은 영상에서 주변과 구분되는 특징을 잡아낼 수 있는 점
                //예시로 컬러가 구분되는 두 사물의 접점
                //특징 점들의 3차원 좌표값을 가진 포인트들의 값을 받아온다
                PointCloud pointCloud = frame.acquirePointCloud();
                //포인트클라우드를 그리기위해 렌더러에 전달
                mRenderer.updatePointCloud(pointCloud);
                pointCloud.release();
                //터치 입력후 boolen값이 true가 된다면
                //터치된 좌표(X,Y)를 Hitresult에 넘겨준다
                //만약 해당 위치에서 감지된 점이 있다면 결과는 Hitresult 객체에 저장되어 반환값으로 받아옵니다.
                //여기서 Hitresult는 카메라와 Hit된 점 사이의 거리, 카메라와 Hit된 점 사이의 포즈 정보 등을 저장하고 있는 클래스입니다.
                if (mTouched) {
                    mTextString = "";
                    //List 객체에는 거리가 가까운 결과순으로 저장됩니다.
                    List<HitResult> results = frame.hitTest(mCurrentX, mCurrentY);
                    int i = 0;
                    for (HitResult result : results) {
                        float distance = result.getDistance();
                        //Pose 객체를 getHitPose()함수를 통해 받아온다.
                        //Pose 객체는 터치된 위치의 3차원 정보를 갖고 있다.
                        Pose pose = result.getHitPose();

                        float[] xAxis = pose.getXAxis();
                        float[] yAxis = pose.getYAxis();
                        float[] zAxis = pose.getZAxis();
                        //클릭한 곳에 좌표계를 그리기 위한 선 설정
                        mRenderer.addPoint(pose.tx(), pose.ty(), pose.tz());
                        mRenderer.addLineX(pose.tx(), pose.ty(), pose.tz(),
                                             xAxis[0], xAxis[1], xAxis[2]);
                        mRenderer.addLineY(pose.tx(), pose.ty(), pose.tz(),
                                             yAxis[0], yAxis[1], yAxis[2]);
                        mRenderer.addLineZ(pose.tx(), pose.ty(), pose.tz(),
                                             zAxis[0], zAxis[1], zAxis[2]);
                        mTextString += ("[" + i + "] distance : " + distance
                                + ", Pose : " + pose.toString() + "\n");
                        i++;
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mTextView.setText(mTextString);
                        }
                    });
                    mTouched = false;
                }
                //포인트 클라우드도 OpenGL에서 공부하였던 것 처럼
                // Model matrix, View matrix, 투영 matrix가 필요하다
                //포인트 클라우드를 받아오는 시점에서 포인트들의 좌표를 받기때문에 model matrix는 불필요
                //먼저 frame 객체에서 현재 프레임에서의 카메라에 대한 정보를 갖는 Camera 객체를 받아온다
                //Projection과 View 매트릭스를 적용시켜 디바이스의 움직임에 따라 현실세계의
                //특정 위치에 고정되어 있는 점을 확인 할 수 있다.
                //먼저 frame 객체에서 현재 프레임에서의 카메라에 대한 정보를 갖는 Camera 객체를 받아온다
                Camera camera = frame.getCamera();
                //투영 matrix가 저장되는 배열
                float[] projMatrix = new float[16];
                //저장되는 배열, offset,near,far를 인자로 줍니다
                camera.getProjectionMatrix(projMatrix, 0, 0.1f, 100.0f);
                //view matrix가 저장되는 배열
                float[] viewMatrix = new float[16];
                //저장되는 배열, offset을 인자로 줍니다.
                camera.getViewMatrix(viewMatrix, 0);

                //각 matrix를 렌더러에 전달
                mRenderer.setProjectionMatrix(projMatrix);
                mRenderer.updateViewMatrix(viewMatrix);
            }
        });
        mSurfaceView.setPreserveEGLContextOnPause(true);
        mSurfaceView.setEGLContextClientVersion(2);
        mSurfaceView.setRenderer(mRenderer);
    }

    @Override
    protected void onPause() {
        super.onPause();

        mSurfaceView.onPause();
        mSession.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();

        requestCameraPermission();

        try {
            if (mSession == null) {
                switch (ArCoreApk.getInstance().requestInstall(this, mUserRequestedInstall)) {
                    case INSTALLED:
                        mSession = new Session(this);
                        Log.d(TAG, "ARCore Session created.");
                        break;
                    case INSTALL_REQUESTED:
                        mUserRequestedInstall = false;
                        Log.d(TAG, "ARCore should be installed.");
                        break;
                }
            }
        }
        catch (UnsupportedOperationException e) {
            Log.e(TAG, e.getMessage());
        }

        mConfig = new Config(mSession);
        if (!mSession.isSupported(mConfig)) {
            Log.d(TAG, "This device is not support ARCore.");
        }
        mSession.configure(mConfig);
        mSession.resume();

        mSurfaceView.onResume();
        mSurfaceView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }
    //onTouchEvent함수를 오버라이딩하여 터치 이벤트가 발생한 스크린 좌표를 터치위해 선언한 변수에 저장
    //ARCore에서는 Ray cast 방식을 사용하여 3차원 포인트를 측정합니다. 이는 카메라가 바라보는 방향으로 가상의 광선을 쏘고
    //해당 프레임에서 감지된 지오메트리와 광선이 만나는 지점의 저을 구합니다.
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mCurrentX = event.getX();
                mCurrentY = event.getY();
                mTouched = true;
                break;
        }
        return true;
    }

    private void requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 0);
        }
    }

    private void hideStatusBarAndTitleBar() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
}
