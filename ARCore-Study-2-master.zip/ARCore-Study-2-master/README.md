# ARCore-Study-2
주석을 작성하며 공부한 것입니다.  
#탱고 & ARCore 증강현실 프로그래밍의 7장 2챕터입니다.  
환경 설정방법은 이곳을 참고하시면 됩니다.  
https://blog.naver.com/bdg9412/221948942815  
