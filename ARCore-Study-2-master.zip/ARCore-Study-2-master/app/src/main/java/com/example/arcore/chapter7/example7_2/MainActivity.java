package com.example.arcore.chapter7.example7_2;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.hardware.display.DisplayManager;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;

import com.google.ar.core.ArCoreApk;
import com.google.ar.core.Camera;
import com.google.ar.core.Config;
import com.google.ar.core.Frame;
import com.google.ar.core.PointCloud;
import com.google.ar.core.Session;

public class MainActivity extends Activity {
    private static final String TAG = MainActivity.class.getSimpleName();
    //GLSurfaceView 객체를 멤버 변수로 선언
    private GLSurfaceView mSurfaceView;
    //OpenGL ES를 사용하기위해
    private MainRenderer mRenderer;

    private boolean mUserRequestedInstall = true;
    //Session 객체를 생성합니다.
    //Session 클래스는 ARCore API사용을 위한 진입점이 됩니다.
    //이로써 카메라 이미지, 디바이스의 포즈에 접근할 수 있는 프레임 을 받아올 수 있습니다.
    private Session mSession;
    //config 객체를 생성합니다.
    //setting을 위하여 사용합니다.
    private Config mConfig;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideStatusBarAndTitleBar();
        setContentView(R.layout.activity_main);
        //findViewById함수를 이용하여 레이아웃으로부터 GLSurfaceView 객체를 받아온다
        mSurfaceView = (GLSurfaceView) findViewById(R.id.gl_surface_view);

        //디스플레이 방향이 바뀔때마다 방향변화를 알리기위한 콜백 함수
        DisplayManager displayManager = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        if (displayManager != null) {
            displayManager.registerDisplayListener(new DisplayManager.DisplayListener() {
                @Override
                public void onDisplayAdded(int displayId) {
                }

                @Override
                public void onDisplayChanged(int displayId) {
                    synchronized (this) {
                        mRenderer.onDisplayChanged();
                    }
                }

                @Override
                public void onDisplayRemoved(int displayId) {
                }
            }, null);
        }

        mRenderer = new MainRenderer(new MainRenderer.RenderCallback() {
            //새로운 프레임을 받아왔을 때 처리를 preRender가 맡아서 한다.
            @Override
            public void preRender() {
                if (mRenderer.isViewportChanged()) {
                    Display display = getWindowManager().getDefaultDisplay();
                    int displayRotation = display.getRotation();
                    //Session의 디스플레이 방향을 설정
                    //Session클래스의 setDisplayGeometry()를 이용하여 디스플레이 방향 설정 가능
                    //이때 화면 방향과 화면 크기를 인자로 주어야 한다
                    mRenderer.updateSession(mSession, displayRotation);
                }

                //렌더러에서 생성한 텍스쳐를 Session 객체와 연결 시키는 부분
                mSession.setCameraTextureName(mRenderer.getTextureId());

                //frame 변화시 이를 반환(반환 값은 frame)하여 할당
                Frame frame = mSession.update();
                if (frame.hasDisplayGeometryChanged()) {
                    mRenderer.transformDisplayGeometry(frame);
                }

                //ARCore 상에서의 포인트 클라우드는 3차원 정보를 갖는 특징점들의 모음
                //이때의 특징점은 영상에서 주변과 구분되는 특징을 잡아낼 수 있는 점
                //예시로 컬러가 구분되는 두 사물의 접점
                //특징 점들의 3차원 좌표값을 가진 포인트들의 값을 받아온다
                PointCloud pointCloud = frame.acquirePointCloud();
                //포인트클라우드를 그리기위해 렌더러에 전달
                mRenderer.updatePointCloud(pointCloud);
                //렌더러에 포인트 클라우드 정보에 대한 업데이트를 해 준 뒤 realse()호출
                pointCloud.release();
                //포인트 클라우드도 OpenGL에서 공부하였던 것 처럼
                // Model matrix, View matrix, 투영 matrix가 필요하다
                //포인트 클라우드를 받아오는 시점에서 포인트들의 좌표를 받기때문에 model matrix는 불필요
                //먼저 frame 객체에서 현재 프레임에서의 카메라에 대한 정보를 갖는 Camera 객체를 받아온다
                Camera camera = frame.getCamera();
                //투영 matrix가 저장되는 배열
                float[] projMatrix = new float[16];
                //저장되는 배열, offset,near,far를 인자로 줍니다
                camera.getProjectionMatrix(projMatrix, 0, 0.1f, 100.0f);
                //view matrix가 저장되는 배열
                float[] viewMatrix = new float[16];
                //저장되는 배열, offset을 인자로 줍니다.
                camera.getViewMatrix(viewMatrix, 0);

                //각 matrix를 렌더러에 전달
                mRenderer.setProjectionMatrix(projMatrix);
                mRenderer.updateViewMatrix(viewMatrix);
            }
        });
        mSurfaceView.setPreserveEGLContextOnPause(true);
        mSurfaceView.setEGLContextClientVersion(2);
        mSurfaceView.setRenderer(mRenderer);
    }

    @Override
    protected void onPause() {
        super.onPause();

        mSurfaceView.onPause();
        mSession.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();

        requestCameraPermission();

        try {
            if (mSession == null) {
                switch (ArCoreApk.getInstance().requestInstall(this, mUserRequestedInstall)) {
                    case INSTALLED:
                        mSession = new Session(this);
                        Log.d(TAG, "ARCore Session created.");
                        break;
                    case INSTALL_REQUESTED:
                        mUserRequestedInstall = false;
                        Log.d(TAG, "ARCore should be installed.");
                        break;
                }
            }
        }
        catch (UnsupportedOperationException e) {
            Log.e(TAG, e.getMessage());
        }

        mConfig = new Config(mSession);
        if (!mSession.isSupported(mConfig)) {
            Log.d(TAG, "This device is not support ARCore.");
        }
        mSession.configure(mConfig);
        mSession.resume();

        mSurfaceView.onResume();
        mSurfaceView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }

    private void requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 0);
        }
    }

    private void hideStatusBarAndTitleBar() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
}
