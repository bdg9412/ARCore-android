package com.example.arcore.chapter7.example7_4;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.hardware.display.DisplayManager;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.ar.core.ArCoreApk;
import com.google.ar.core.Camera;
import com.google.ar.core.Config;
import com.google.ar.core.Frame;
import com.google.ar.core.HitResult;
import com.google.ar.core.PointCloud;
import com.google.ar.core.Pose;
import com.google.ar.core.Session;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String TAG = MainActivity.class.getSimpleName();

    private TextView mTextView;
    //GLSurfaceView 객체를 멤버 변수로 선언
    private GLSurfaceView mSurfaceView;
    //OpenGL ES를 사용하기위해
    private MainRenderer mRenderer;

    private boolean mUserRequestedInstall = true;
    //ARCore API 호출할 수 있는 진입점인 Session 객체
    //Session 객체를 멤버변수로 설정
    private Session mSession;
    private Config mConfig;

    private List<float[]> mPoints = new ArrayList<float[]>();

    private float mLastX;
    private float mLastY;
    private boolean mPointAdded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideStatusBarAndTitleBar();
        setContentView(R.layout.activity_main);

        //findViewById함수를 이용하여 레이아웃으로부터 TextView 객체를 받아온다
        mTextView = (TextView) findViewById(R.id.ar_core_text);
        //findViewById함수를 이용하여 레이아웃으로부터 GLSurfaceView 객체를 받아온다
        mSurfaceView = (GLSurfaceView) findViewById(R.id.gl_surface_view);
        //디바이스 방향 설정
        //디스플레이 방향이 바뀔때마다 방향변화를 알리기위한 콜백 함수
        DisplayManager displayManager = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        if (displayManager != null) {
            displayManager.registerDisplayListener(new DisplayManager.DisplayListener() {
                @Override
                public void onDisplayAdded(int displayId) {
                }
                //디스플레이 변경만을 알려준다
                //설정 변경은 preRender()에서 진행
                @Override
                public void onDisplayChanged(int displayId) {
                    synchronized (this) {
                        mRenderer.onDisplayChanged();
                    }
                }

                @Override
                public void onDisplayRemoved(int displayId) {
                }
            }, null);
        }

        mRenderer = new MainRenderer(new MainRenderer.RenderCallback() {
            @Override
            public void preRender() {
                //디스플레이 방향이 변경되었을 경우 디스플레이 방향에 맞는 설정
                if (mRenderer.isViewportChanged()) {
                    Display display = getWindowManager().getDefaultDisplay();
                    int displayRotation = display.getRotation();
                    //Session의 디스플레이 방향을 설정
                    //updateSesiion은 setDisplayGeometry()호출
                    //Session클래스의 setDisplayGeometry()를 이용하여 디스플레이 방향 설정 가능
                    mRenderer.updateSession(mSession, displayRotation);
                }
                //렌더러에서 카메라 영상을 그리기 위해 생성한 텍스쳐 객체를 Session 객체와 연결시켜 준다.
                mSession.setCameraTextureName(mRenderer.getTextureId());

                //frame 변화시 이를 반환(반환 값은 frame)하여 할당
                Frame frame = mSession.update();
                if (frame.hasDisplayGeometryChanged()) {
                    mRenderer.transformDisplayGeometry(frame);
                }

                //ARCore 상에서의 포인트 클라우드는 3차원 정보를 갖는 특징점들의 모음
                //이때의 특징점은 영상에서 주변과 구분되는 특징을 잡아낼 수 있는 점
                //예시로 컬러가 구분되는 두 사물의 접점
                //특징 점들의 3차원 좌표값을 가진 포인트들의 값을 frame으로부터 받아온다
                PointCloud pointCloud = frame.acquirePointCloud();
                mRenderer.updatePointCloud(pointCloud);
                pointCloud.release();
                //터치 입력후 boolen값이 true가 된다면
                //터치된 좌표(X,Y)를 Hitresult에 넘겨준다
                //만약 해당 위치에서 감지된 점이 있다면 결과는 Hitresult 객체에 저장되어 반환값으로 받아옵니다.
                //여기서 Hitresult는 카메라와 Hit된 점 사이의 거리, 카메라와 Hit된 점 사이의 포즈 정보 등을 저장하고 있는 클래스입니다.
                if (mPointAdded) {
                    List<HitResult> results = frame.hitTest(mLastX, mLastY);
                    for (HitResult result : results) {
                        //Pose 객체를 getHitPose()함수를 통해 받아온다.
                        //Pose 객체는 터치된 위치의 3차원 정보를 갖고 있다.
                        Pose pose = result.getHitPose();
                        float[] points = new float[]{ pose.tx(), pose.ty(), pose.tz() };
                        //거리계산을 위해 mPoints함수에 좌표 정보를 인자로 전달
                        mPoints.add(points);
                        //렌더러에 좌표 정보를 전달
                        mRenderer.addPoint(points);
                        updateDistance();
                    }
                    mPointAdded = false;
                }

                Camera camera = frame.getCamera();
                float[] projMatrix = new float[16];
                camera.getProjectionMatrix(projMatrix, 0, 0.1f, 100.0f);
                float[] viewMatrix = new float[16];
                camera.getViewMatrix(viewMatrix, 0);

                mRenderer.setProjectionMatrix(projMatrix);
                mRenderer.updateViewMatrix(viewMatrix);
            }
        });
        //렌더러 생성 후 GLSurfaceView에 설정
        mSurfaceView.setPreserveEGLContextOnPause(true);
        mSurfaceView.setEGLContextClientVersion(2);
        mSurfaceView.setRenderer(mRenderer);
        mSurfaceView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }

    @Override
    protected void onPause() {
        super.onPause();

        mSurfaceView.onPause();
        mSession.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();

        requestCameraPermission();
        //ARCore SDK가 설치되었는지 여부 확인 및 설치 요청
        try {
            if (mSession == null) {
                switch (ArCoreApk.getInstance().requestInstall(this,
                        mUserRequestedInstall)) {
                    case INSTALLED:
                        mSession = new Session(this);
                        Log.d(TAG, "ARCore Session created.");
                        break;
                    case INSTALL_REQUESTED:
                        mUserRequestedInstall = false;
                        Log.d(TAG, "ARCore should be installed.");
                        break;
                }
            }
        }
        catch (UnsupportedOperationException e) {
            Log.e(TAG, e.getMessage());
        }
        //Session 객체 생성 후 ARCore 환경 값 설정할 수 있는 Config 객체를 생성
        mConfig = new Config(mSession);
        if (!mSession.isSupported(mConfig)) {
            Log.d(TAG, "This device is not support ARCore.");
        }
        mSession.configure(mConfig);
        mSession.resume();

        mSurfaceView.onResume();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mLastX = event.getX();
                mLastY = event.getY();
                mPointAdded = true;
                break;
        }
        return true;
    }
    //버튼 이벤트 관련 함수
    public void onRemoveButtonClick(View view) {
        if (!mPoints.isEmpty()) {
            mPoints.remove(mPoints.size() - 1);
            mRenderer.removePoint();
            updateDistance();
        }
    }
    //특징점을 획득할 시 거리 계산하는 함수
    public void updateDistance() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //거리 변수선언 및 0으로 초기화
                double totalDistance = 0.0;
                if (mPoints.size() >= 2)  {
                    for (int i = 0; i < mPoints.size() - 1; i++) {
                        System.out.println(mPoints.get(i)+" "+mPoints.get(i+1)+" "+mPoints.get(i+2)+" ");
                        float[] start = mPoints.get(i);
                        float[] end = mPoints.get(i + 1);

                        double distance = Math.sqrt(
                                (start[0] - end[0]) * (start[0] - end[0])
                                + (start[1] - end[1]) * (start[1] - end[1])
                                + (start[2] - end[2]) * (start[2] - end[2]));
                        totalDistance += distance;
                    }
                }
                String distanceString = String.format(Locale.getDefault(),
                        "%.2f", totalDistance)
                        + getString(R.string.distance_unit_text);
                mTextView.setText(distanceString);
            }
        });
    }
    //manifest 카메라 권한을 추가하였지만 실제 카메라 권한을 모바일 디바이스에서 부여받기위하여
    //다음의 함수를 이용하여 권한을 부여받습니다.
    //이를 onResume()함수에서 불러줍니다.
    private void requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA}, 0);
        }
    }
    //전체화면으로 보기위하여 상태 바, 타이틀 바 제거
    //이를 레이아웃 설정하기전에 onCreate()함수에서 호출
    private void hideStatusBarAndTitleBar() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

}
